const GRID = 50;
const CELL = 10;

const canvas = document.getElementById('canvas');
const ctx = canvas.getContext('2d');

let px, py, tx, ty, obstacles, moves, best, currentLevel;

// ─── Initialise ───────────────────────────────────────────────

function loadLevel(index) {
  currentLevel = index;
  const level = levels[index];

  px = level.playerStart.x;
  py = level.playerStart.y;
  tx = level.target.x;
  ty = level.target.y;
  obstacles = level.obstacles;

  moves = 0;

  document.getElementById('level').textContent = currentLevel + 1;
  document.getElementById('moves').textContent = 0;
  document.getElementById('best').textContent = best || '—';
  document.getElementById('msg').textContent = 'use arrow keys or WASD to move';

  draw();
  canvas.focus();
}

function restartLevel() {
  best = undefined;
  loadLevel(currentLevel);
}

function nextLevel() {
  best = undefined;
  const next = (currentLevel + 1) % levels.length;
  loadLevel(next);
}

// ─── Drawing ──────────────────────────────────────────────────

function draw() {
  // Background
  ctx.fillStyle = '#f5f4ef';
  ctx.fillRect(0, 0, 500, 500);

  // Grid cells
  for (let x = 0; x < GRID; x++) {
    for (let y = 0; y < GRID; y++) {
      ctx.fillStyle = '#e0dfd8';
      ctx.fillRect(x * CELL + 1, y * CELL + 1, CELL - 1, CELL - 1);
    }
  }

  // Obstacles
  obstacles.forEach(o => {
    ctx.fillStyle = '#444441';
    ctx.fillRect(o.x * CELL + 1, o.y * CELL + 1, CELL - 1, CELL - 1);
  });

  // Target
  ctx.fillStyle = '#E1F5EE';
  ctx.fillRect(tx * CELL + 1, ty * CELL + 1, CELL - 1, CELL - 1);
  ctx.fillStyle = '#1D9E75';
  ctx.fillRect(tx * CELL + 3, ty * CELL + 3, CELL - 5, CELL - 5);

  // Player
  ctx.fillStyle = '#7F77DD';
  ctx.fillRect(px * CELL + 1, py * CELL + 1, CELL - 1, CELL - 1);
}

// ─── Movement ─────────────────────────────────────────────────

function isObstacle(x, y) {
  return obstacles.some(o => o.x === x && o.y === y);
}

function tryMove(dx, dy) {
  const nx = px + dx;
  const ny = py + dy;

  // Check bounds
  if (nx < 0 || nx >= GRID || ny < 0 || ny >= GRID) return;

  // Check obstacles
  if (isObstacle(nx, ny)) return;

  px = nx;
  py = ny;
  moves++;

  document.getElementById('moves').textContent = moves;

  // Check win
  if (px === tx && py === ty) {
    if (best === undefined || moves < best) best = moves;
    document.getElementById('best').textContent = best;
    document.getElementById('msg').textContent = `got it in ${moves} moves!`;
  }

  draw();
}

// ─── Input ────────────────────────────────────────────────────

document.addEventListener('keydown', (e) => {
  const map = {
    ArrowUp: [0, -1], w: [0, -1], W: [0, -1],
    ArrowDown: [0, 1], s: [0, 1], S: [0, 1],
    ArrowLeft: [-1, 0], a: [-1, 0], A: [-1, 0],
    ArrowRight: [1, 0], d: [1, 0], D: [1, 0]
  };
  const dir = map[e.key];
  if (!dir) return;
  e.preventDefault();
  tryMove(dir[0], dir[1]);
});

// ─── Start ────────────────────────────────────────────────────

loadLevel(0);
