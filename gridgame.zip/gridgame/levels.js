// Each level defines:
// - playerStart: where the player begins {x, y}
// - target: where the player needs to get to {x, y}
// - obstacles: array of blocked cells [{x, y}, ...]

const levels = [
  {
    playerStart: { x: 0, y: 0 },
    target: { x: 49, y: 49 },
    obstacles: []
  },
  {
    playerStart: { x: 0, y: 25 },
    target: { x: 49, y: 25 },
    obstacles: [
      { x: 15, y: 23 }, { x: 15, y: 24 }, { x: 15, y: 25 },
      { x: 15, y: 26 }, { x: 15, y: 27 },
      { x: 30, y: 22 }, { x: 30, y: 23 }, { x: 30, y: 24 },
      { x: 30, y: 25 }, { x: 30, y: 26 }
    ]
  },
  {
    playerStart: { x: 0, y: 0 },
    target: { x: 49, y: 49 },
    obstacles: [
      // horizontal wall with a gap
      { x: 10, y: 15 }, { x: 11, y: 15 }, { x: 12, y: 15 },
      { x: 13, y: 15 }, { x: 14, y: 15 }, { x: 16, y: 15 },
      { x: 17, y: 15 }, { x: 18, y: 15 }, { x: 19, y: 15 },
      // vertical wall with a gap
      { x: 30, y: 20 }, { x: 30, y: 21 }, { x: 30, y: 22 },
      { x: 30, y: 24 }, { x: 30, y: 25 }, { x: 30, y: 26 }
    ]
  }
];
